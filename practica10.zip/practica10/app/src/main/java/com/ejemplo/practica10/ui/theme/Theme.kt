package com.ejemplo.practica10.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val EsquemaClaro = lightColorScheme(
    primary = Azul40,
    onPrimary = Color.White,
    primaryContainer = Azul80,
    onPrimaryContainer = Color(0xFF001D36),
    secondary = Verde40,
    onSecondary = Color.White,
    secondaryContainer = Verde80,
    onSecondaryContainer = Color(0xFF002118)
)

private val EsquemaOscuro = darkColorScheme(
    primary = Azul80,
    onPrimary = Color(0xFF00326B),
    primaryContainer = Azul40,
    onPrimaryContainer = Color(0xFFD1E4FF),
    secondary = Verde80,
    onSecondary = Color(0xFF00382B),
    secondaryContainer = Verde40,
    onSecondaryContainer = Color(0xFFA0F2D6)
)

@Composable
fun Practica10Theme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Desactivado para que priorice nuestra paleta personalizada
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> EsquemaOscuro
        else -> EsquemaClaro
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}