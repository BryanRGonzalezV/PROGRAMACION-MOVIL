package com.ejemplo.practica10

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ejemplo.practica10.ui.theme.Practica10Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Practica10Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppPrincipal()
                }
            }
        }
    }
}

// ── MODELO Y DATOS DE MUESTRA ─────────────────────────────────────────

data class Afirmacion(val id: Int, val texto: String, val categoria: String)

val afirmaciones = listOf(
    Afirmacion(1, "El código limpio no se escribe, se refactoriza.", "Código"),
    Afirmacion(2, "Un bug encontrado es un bug que ya no puede fallar en producción.", "Debug"),
    Afirmacion(3, "Git commit temprano, git commit seguido.", "Versionamiento"),
    Afirmacion(4, "La documentación es una carta para tu yo futuro.", "Buenas prácticas"),
    Afirmacion(5, "Divide el problema y conquista.", "Algoritmos")
)

// Modelo para navegación inferior
data class ItemNav(val ruta: String, val etiqueta: String, val icono: ImageVector)

val itemsNav = listOf(
    ItemNav("inicio", "Inicio", Icons.Default.Home),
    ItemNav("lista", "Lista", Icons.Default.List),
    ItemNav("perfil", "Perfil", Icons.Default.Person)
)

// ── ESTRUCTURA PRINCIPAL DE LA APP (SCAFFOLD + NAVHOST) ────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppPrincipal() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val rutaActual = backStackEntry?.destination?.route
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mi App Android") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                // TODO Resuelto: Agregado IconButton con Settings en 'actions'
                actions = {
                    IconButton(onClick = {
                        Toast.makeText(context, "Ajustes presionados", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Ajustes",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                itemsNav.forEach { item ->
                    NavigationBarItem(
                        selected = rutaActual == item.ruta,
                        onClick = {
                            navController.navigate(item.ruta) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icono, contentDescription = item.etiqueta) },
                        label = { Text(item.etiqueta) }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "inicio",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("inicio") { PantallaInicio(navController) }
            composable("lista") { PantallaLista(navController) }
            composable("perfil") { PantallaPerfil() }

            // Pantalla con Argumento (Ej. 3)
            composable(
                route = "detalle/{itemId}",
                arguments = listOf(navArgument("itemId") { type = NavType.IntType })
            ) { backStack ->
                val id = backStack.arguments?.getInt("itemId") ?: 0
                PantallaDetalle(id, navController)
            }
        }
    }
}

// ── PANTALLAS DE LA APLICACIÓN ────────────────────────────────────────

@Composable
fun PantallaInicio(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "¡Bienvenido a la Práctica 10!",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Explora las secciones utilizando la barra de navegación inferior.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = { navController.navigate("lista") }) {
            Text("Ver lista de afirmaciones")
        }
    }
}

@Composable
fun PantallaLista(navController: NavController) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "Afirmaciones Motivacionales",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(afirmaciones) { afirmacion ->
                // TODO Resuelto: Click en ItemAfirmacion navega al detalle pasando el ID
                ItemAfirmacion(
                    afirmacion = afirmacion,
                    onItemClick = { navController.navigate("detalle/${afirmacion.id}") }
                )
            }
        }
    }
}

@Composable
fun ItemAfirmacion(afirmacion: Afirmacion, onItemClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${afirmacion.id}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = afirmacion.categoria,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(text = afirmacion.texto, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun PantallaPerfil() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(text = "Perfil de Usuario", style = MaterialTheme.typography.titleLarge)
        Text(
            text = "Estudiante Android - UNICDA 2026",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PantallaDetalle(itemId: Int, navController: NavController) {
    val afirmacion = afirmaciones.find { it.id == itemId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (afirmacion != null) {
            Text(
                text = afirmacion.categoria.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "\"${afirmacion.texto}\"",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
        } else {
            Text("Afirmación no encontrada")
        }
        Spacer(Modifier.height(32.dp))
        OutlinedButton(onClick = { navController.popBackStack() }) {
            Text("Regresar")
        }
    }
}

// ── PREVISUALIZACIÓN DE TEMA (EJ. 1) ──────────────────────────────────

@Preview(showBackground = true)
@Composable
fun PreviewTema() {
    Practica10Theme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedButton(onClick = {}) { Text("Botón outline") }
                Spacer(Modifier.height(8.dp))
                Card { Text("Card con tema", Modifier.padding(16.dp)) }
            }
        }
    }
}