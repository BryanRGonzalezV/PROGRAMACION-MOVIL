package com.ejemplo.practica04

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val resultadoPractica = obtenerResultadoPractica()

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaPractica(contenido = resultadoPractica)
                }
            }
        }
    }
}

@Composable
fun PantallaPractica(contenido: String) {
    val scrollState = rememberScrollState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        Text(
            text = contenido,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

fun obtenerResultadoPractica(): String {
    val sb = StringBuilder()

    sb.appendLine(">>> EJERCICIO 1: Parámetros nombrados <<<\n")
    sb.appendLine(generarRecibo(nombreCliente = "Ana López", monto = 1500.0, descuento = 0.10))
    sb.appendLine()
    sb.appendLine(generarRecibo("Pedro Ruiz", 2800.0))
    sb.appendLine()
    sb.appendLine(generarRecibo(monto = 500.0, nombreCliente = "Empresa ABC", moneda = "USD", impuesto = 0.0))

    sb.appendLine("\n" + "─".repeat(35) + "\n")

    sb.appendLine(">>> EJERCICIO 2: Extensiones <<<\n")
    sb.appendLine("Validar Email 'test@mail.com': ${"test@mail.com".esEmail()}")
    sb.appendLine("Validar Email 'noesmail': ${"noesmail".esEmail()}")
    sb.appendLine("Formato Título: ${"programacion movil".aTitulo()}")
    sb.appendLine("Tarjeta Enmascarada: ${"1234567890123456".mascararTarjeta()}")

    val notas = listOf(85, 92, 61, 78, 45, 90)
    sb.appendLine("\nNotas: $notas")
    sb.appendLine("Promedio: ${String.format(Locale.US, "%.2f", notas.promedio())}")
    sb.appendLine("Aprobados: ${notas.aprobados()}")
    sb.appendLine(notas.estadisticas())

    sb.appendLine("\n" + "─".repeat(35) + "\n")

    sb.appendLine(">>> EJERCICIO 3: Ámbito y Lambdas <<<\n")

    // apply: configura el objeto durante su creación
    val p1 = Pedido(1, "", 0.0).apply {
        producto = "Smartphone"
        precio = 25000.0
    }

    val pedidos = listOf(
        p1,
        Pedido(2, "Audífonos", 1800.0),
        Pedido(3, "Tablet", 18000.0, activo = false),
        Pedido(4, "Cargador", 850.0)
    )

    val activos = filtrarPedidos(pedidos) { it.activo }
    val caros = filtrarPedidos(pedidos) { it.precio > 5000.0 && it.activo }

    sb.appendLine("Pedidos activos: ${activos.size}")
    sb.appendLine("Pedidos caros: ${caros.map { it.producto }}")

    // also: ejecuta un bloque y retorna el objeto original
    val resumen = pedidos
        .filter { it.activo }
        .map { it.precio }
        .also { sb.appendLine("Precios activos: $it") }
        .sum()

    sb.appendLine("Total activos: $${String.format(Locale.US, "%.2f", resumen)}")

    // let: uso seguro
    pedidos.maxByOrNull { it.precio }?.let { pedido ->
        sb.appendLine("\nProducto más caro: ${pedido.producto} ($${String.format(Locale.US, "%.2f", pedido.precio)})")
    }

    return sb.toString()
}