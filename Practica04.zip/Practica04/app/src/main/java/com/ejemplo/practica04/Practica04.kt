package com.ejemplo.practica04

import java.util.Locale

// ============================================================================
// Ejercicio 1: Parámetros nombrados y valores por defecto
// ============================================================================
fun generarRecibo(
    nombreCliente: String,
    monto: Double,
    descuento: Double = 0.0, // opcional
    impuesto: Double = 0.18, // ITBIS 18% por defecto
    moneda: String = "DOP"
): String {
    val subtotal = monto - (monto * descuento)
    val impuestoVal = subtotal * impuesto
    val total = subtotal + impuestoVal

    val porcDescuento = (descuento * 100).toInt()
    val porcImpuesto = (impuesto * 100).toInt()

    return """
        ===========================
        RECIBO — $moneda
        Cliente   : $nombreCliente
        Subtotal  : $moneda ${String.format(Locale.US, "%.2f", subtotal)}
        Descuento : $porcDescuento%
        Impuesto  : $porcImpuesto% ($moneda ${String.format(Locale.US, "%.2f", impuestoVal)})
        Total     : $moneda ${String.format(Locale.US, "%.2f", total)}
        ===========================
    """.trimIndent()
}

// ============================================================================
// Ejercicio 2: Funciones de extensión
// ============================================================================

// ── Extensiones de String ────────────────────────────────────────────────----
fun String.esEmail(): Boolean = contains('@') && contains('.')

fun String.aTitulo(): String = split(' ').joinToString(" ") { palabra ->
    palabra.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
}

// Extensión mascararTarjeta(): Oculta los primeros 12 dígitos
fun String.mascararTarjeta(): String {
    if (this.length < 16) return this
    val ultimosCuatro = this.takeLast(4)
    return "*".repeat(this.length - 4) + ultimosCuatro
}

// ── Extensiones de List ──────────────────────────────────────────────────────
fun List<Int>.promedio(): Double = if (isEmpty()) 0.0 else sum().toDouble() / size

// Extensión aprobados(): Retorna lista de notas >= 70
fun List<Int>.aprobados(): List<Int> = this.filter { it >= 70 }

// Extensión estadisticas(): Retorna un String con min, max y promedio
fun List<Int>.estadisticas(): String {
    if (this.isEmpty()) return "La lista de notas está vacía."

    val min = this.minOrNull() ?: 0
    val max = this.maxOrNull() ?: 0
    val prom = this.promedio()

    return """
        ── Estadísticas ──
        Nota Mínima  : $min
        Nota Máxima  : $max
        Promedio     : ${String.format(Locale.US, "%.2f", prom)}
    """.trimIndent()
}

// ============================================================================
// Ejercicio 3: Funciones de orden superior y ámbito
// ============================================================================
data class Pedido(
    val id: Int,
    var producto: String,
    var precio: Double,
    var activo: Boolean = true
)

// Función de orden superior: recibe una lambda como filtro
fun filtrarPedidos(pedidos: List<Pedido>, criterio: (Pedido) -> Boolean): List<Pedido> {
    return pedidos.filter(criterio)
}