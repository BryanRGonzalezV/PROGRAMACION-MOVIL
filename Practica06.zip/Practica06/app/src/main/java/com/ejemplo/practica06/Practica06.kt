package com.ejemplo.practica06

import android.util.Log

private const val TAG = "PRACTICA06"

// ==========================================
// EJERCICIO 1: DATA CLASS — GESTOR DE TAREAS
// ==========================================

enum class Prioridad { BAJA, MEDIA, ALTA, CRITICA }

data class Tarea(
    val id: Int,
    val titulo: String,
    val descripcion: String = "",
    val prioridad: Prioridad = Prioridad.MEDIA,
    val completada: Boolean = false,
) {
    fun resumen() = "[${if (completada) "X" else " "}] #$id $titulo (${prioridad.name})"
}

// ====================================================
// EJERCICIO 2: SEALED CLASS — RESULTADO Y CONEXIÓN
// ====================================================

sealed class Resultado<out T> {
    data class Exito<T>(val datos: T) : Resultado<T>()
    data class Error(val mensaje: String, val codigo: Int = 0) : Resultado<Nothing>()
    object Cargando : Resultado<Nothing>()
}

// TODO: Sealed class EstadoConexion
sealed class EstadoConexion {
    object Conectado : EstadoConexion()
    object Desconectado : EstadoConexion()
    data class Reconectando(val intentos: Int) : EstadoConexion()
}

fun obtenerEstudiante(id: Int): Resultado<String> = when (id) {
    1 -> Resultado.Exito("Ana López — Ing. Software")
    2 -> Resultado.Exito("Carlos Ruiz — Ing. Software")
    0 -> Resultado.Cargando
    else -> Resultado.Error("Estudiante $id no encontrado", 404)
}

fun manejarResultado(resultado: Resultado<String>) {
    when (resultado) {
        is Resultado.Exito -> Log.d(TAG, "Éxito: ${resultado.datos}")
        is Resultado.Error -> Log.d(TAG, "Error ${resultado.codigo}: ${resultado.mensaje}")
        Resultado.Cargando -> Log.d(TAG, "Cargando...")
    }
}

// TODO: Función para evaluar EstadoConexion
fun manejarEstadoConexion(estado: EstadoConexion) {
    when (estado) {
        is EstadoConexion.Conectado -> Log.d(TAG, "Estado: Conexión establecida con éxito.")
        is EstadoConexion.Desconectado -> Log.d(TAG, "Estado: Sin conexión a Internet.")
        is EstadoConexion.Reconectando -> Log.d(TAG, "Estado: Reintentando conexión (Intento #${estado.intentos})...")
    }
}

// ====================================================
// EJERCICIO 3: COMPANION OBJECT — FÁBRICA DE OBJETOS
// ====================================================

class Producto private constructor(
    val codigo: String,
    val nombre: String,
    val precio: Double,
    val categoria: String,
) {
    companion object {
        const val IMPUESTO = 0.18
        private var contador = 0

        fun crear(nombre: String, precio: Double, categoria: String): Producto {
            contador++
            val codigo = "PROD-${contador.toString().padStart(4, '0')}"
            return Producto(codigo, nombre, precio, categoria)
        }

        fun totalProductosCreados() = contador

        // TODO: Método companion para buscar por categoría
        fun buscarPorCategoria(productos: List<Producto>, cat: String): List<Producto> {
            return productos.filter { it.categoria.equals(cat, ignoreCase = true) }
        }
    }

    val precioConImpuesto: Double get() = precio * (1 + IMPUESTO)

    override fun toString() =
        "[$codigo] $nombre | RD$ %.2f (+ IVA: RD$ %.2f)".format(precio, precioConImpuesto)
}

// ==========================================
// FUNCIÓN PRINCIPAL EJECUTADA EN EL CELULAR
// ==========================================

fun ejecutarPractica06() {
    Log.d(TAG, "==========================================")
    Log.d(TAG, "   EJERCICIO 1: DATA CLASS Y COPY()")
    Log.d(TAG, "==========================================")

    var tarea1 = Tarea(1, "Instalar Android Studio", prioridad = Prioridad.ALTA)
    val tarea2 = Tarea(2, "Crear repositorio GitHub")
    var tarea3 = Tarea(3, "Completar Práctica 1", prioridad = Prioridad.CRITICA)

    tarea1 = tarea1.copy(completada = true)
    tarea3 = tarea3.copy(completada = true)

    val tareas = listOf(tarea1, tarea2, tarea3)

    Log.d(TAG, "=== LISTA DE TAREAS ===")
    tareas.forEach { Log.d(TAG, it.resumen()) }

    val (id, titulo, _, prioridad, completada) = tarea2
    Log.d(TAG, "Tarea $id: '$titulo' - Prioridad: $prioridad - Completada: $completada")

    // TODO: Filtrar y ordenar pendientes por prioridad
    Log.d(TAG, "=== TAREAS PENDIENTES (ORDENADAS POR PRIORIDAD) ===")
    val pendientesOrdenadas = tareas
        .filter { !it.completada }
        .sortedByDescending { it.prioridad.ordinal }

    pendientesOrdenadas.forEach { Log.d(TAG, it.resumen()) }

    Log.d(TAG, "==========================================")
    Log.d(TAG, "   EJERCICIO 2: SEALED CLASS")
    Log.d(TAG, "==========================================")

    listOf(1, 2, 0, 99).forEach { id ->
        Log.d(TAG, "Evaluando ID $id:")
        manejarResultado(obtenerEstudiante(id))
    }

    // TODO: Prueba de EstadoConexion
    Log.d(TAG, "=== ESTADOS DE CONEXIÓN ===")
    val estados: List<EstadoConexion> = listOf(
        EstadoConexion.Conectado,
        EstadoConexion.Desconectado,
        EstadoConexion.Reconectando(1),
        EstadoConexion.Reconectando(3)
    )

    estados.forEach { manejarEstadoConexion(it) }

    Log.d(TAG, "==========================================")
    Log.d(TAG, "   EJERCICIO 3: COMPANION OBJECT")
    Log.d(TAG, "==========================================")

    val p1 = Producto.crear("Samsung Galaxy A55", 22000.0, "Smartphones")
    val p2 = Producto.crear("Funda protectora", 850.0, "Accesorios")
    val p3 = Producto.crear("Audífonos Bluetooth", 3200.0, "Accesorios")

    val listaProductos = listOf(p1, p2, p3)
    listaProductos.forEach { Log.d(TAG, it.toString()) }

    Log.d(TAG, "Total de productos creados: ${Producto.totalProductosCreados()}")

    // TODO: Búsqueda por categoría
    Log.d(TAG, "=== BÚSQUEDA DE PRODUCTOS EN 'Accesorios' ===")
    val accesorios = Producto.buscarPorCategoria(listaProductos, "Accesorios")
    accesorios.forEach { Log.d(TAG, it.toString()) }
}