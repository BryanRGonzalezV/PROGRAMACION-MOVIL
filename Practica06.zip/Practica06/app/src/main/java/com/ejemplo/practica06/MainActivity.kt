package com.ejemplo.practica06

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ejecuta la lógica
        Log.d("PRACTICA06", "=== INICIANDO PRÁCTICA 6 ===")
        ejecutarPractica06()

        // Muestra un texto en la pantalla del celular
        val textView = TextView(this).apply {
            text = "Práctica 6 ejecutada con éxito.\n\nRevisa la pestaña Logcat en Android Studio para ver los resultados de la consola."
            textSize = 18f
            setPadding(50, 100, 50, 0)
        }
        setContentView(textView)
    }
}