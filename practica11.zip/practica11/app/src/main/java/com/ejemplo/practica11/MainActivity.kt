package com.ejemplo.practica11

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ejemplo.practica11.ui.theme.Practica11Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Practica11Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppPrincipal()
                }
            }
        }
    }
}

// ── NAVEGACIÓN SIMPLE PARA PROBAR AMBOS EJERCICIOS ───────────────────

@Composable
fun AppPrincipal() {
    var pestañaSeleccionada by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TabRow(selectedTabIndex = pestañaSeleccionada) {
                Tab(
                    selected = pestañaSeleccionada == 0,
                    onClick = { pestañaSeleccionada = 0 },
                    text = { Text("Ej. 1: Contador") }
                )
                Tab(
                    selected = pestañaSeleccionada == 1,
                    onClick = { pestañaSeleccionada = 1 },
                    text = { Text("Ej. 2: Formulario") }
                )
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (pestañaSeleccionada) {
                0 -> ContadorApp()
                1 -> FormularioRegistro()
            }
        }
    }
}

// ── EJERCICIO 1: CONTADOR CON ESTADO LOCAL Y REMEMBERSAVEABLE ────────

@Composable
fun ContadorApp() {
    // TODO 3: Cambiar remember por rememberSaveable para preservar el estado al rotar
    var contador by rememberSaveable { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "$contador",
            style = MaterialTheme.typography.displayLarge,
            color = when {
                contador > 0 -> MaterialTheme.colorScheme.primary
                contador < 0 -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onBackground
            }
        )

        Spacer(Modifier.height(16.dp))

        // TODO 1: Mostrar mensaje diferente según el valor del contador
        val mensajeEstado = when {
            contador < 0 -> "En números rojos"
            contador > 0 -> "En positivo"
            else -> "En cero"
        }

        Text(
            text = mensajeEstado,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = when {
                contador > 0 -> MaterialTheme.colorScheme.primary
                contador < 0 -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.outline
            }
        )

        Spacer(Modifier.height(32.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalButton(onClick = { contador-- }) { Text("-") }
            Button(onClick = { contador = 0 }) { Text("Reiniciar") }
            FilledTonalButton(onClick = { contador++ }) { Text("+") }
        }

        Spacer(Modifier.height(16.dp))

        // TODO 2: Agregar un botón Duplicar que multiplique el contador x2
        OutlinedButton(
            onClick = { contador *= 2 },
            enabled = contador != 0
        ) {
            Text("Duplicar (x2)")
        }
    }
}

// ── EJERCICIO 2: STATE HOISTING Y FORMULARIO REACTIVO ────────────────

@Composable
fun CampoNombre(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text("Nombre completo") },
        singleLine = true,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun FormularioRegistro() {
    var nombre by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var aceptado by rememberSaveable { mutableStateOf(false) }
    var mostrarDialogoExito by rememberSaveable { mutableStateOf(false) }

    // Validaciones reactivas
    val nombreValido = nombre.trim().length >= 3
    val emailValido = email.contains('@') && email.contains('.')
    val puedeEnviar = nombreValido && emailValido && aceptado

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Registro de Usuario",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        // Campo Nombre
        CampoNombre(
            value = nombre,
            onValueChange = { nombre = it }
        )

        // TODO 1: OutlinedTextField para email con teclado adecuado y validación visual
        val emailTieneError = !emailValido && email.isNotEmpty()

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            singleLine = true,
            isError = emailTieneError,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            supportingText = {
                if (emailTieneError) {
                    Text("Email inválido", color = MaterialTheme.colorScheme.error)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = aceptado, onCheckedChange = { aceptado = it })
            Text("Acepto los términos y condiciones")
        }

        // TODO 2: Mostrar Dialog de confirmación al presionar
        Button(
            onClick = { mostrarDialogoExito = true },
            enabled = puedeEnviar,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Registrarse")
        }

        // Indicadores de validación en tiempo real
        if (nombre.isNotEmpty()) {
            Text(
                text = if (nombreValido) "✓ Nombre válido" else "✗ Mínimo 3 caracteres",
                color = if (nombreValido) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error,
                fontSize = 12.sp
            )
        }

        if (email.isNotEmpty()) {
            Text(
                text = if (emailValido) "✓ Correo con formato válido" else "✗ Debe contener '@' y '.'",
                color = if (emailValido) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.error,
                fontSize = 12.sp
            )
        }
    }

    // Modal / Diálogo de Confirmación (TODO 2 del Ejercicio 2)
    if (mostrarDialogoExito) {
        AlertDialog(
            onDismissRequest = { mostrarDialogoExito = false },
            title = { Text("¡Registro exitoso!") },
            text = { Text("El usuario '$nombre' ($email) se ha registrado correctamente.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        mostrarDialogoExito = false
                        // Limpiar formulario opcionalmente
                        nombre = ""
                        email = ""
                        aceptado = false
                    }
                ) {
                    Text("Aceptar")
                }
            }
        )
    }
}

// ── PREVISUALIZACIÓN ──────────────────────────────────────────────────

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PrevisualizacionApp() {
    Practica11Theme {
        AppPrincipal()
    }
}