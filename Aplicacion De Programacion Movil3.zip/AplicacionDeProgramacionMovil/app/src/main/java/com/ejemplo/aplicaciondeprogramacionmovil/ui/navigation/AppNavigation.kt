package com.ejemplo.aplicaciondeprogramacionmovil.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.ejemplo.aplicaciondeprogramacionmovil.data.Tarea
import com.ejemplo.aplicaciondeprogramacionmovil.ui.navigation.screen.DetalleScreen
import com.ejemplo.aplicaciondeprogramacionmovil.ui.navigation.screen.InicioScreen
import com.ejemplo.aplicaciondeprogramacionmovil.ui.navigation.screen.ListaScreen

sealed class Pantalla(val ruta: String) {
    object Inicio : Pantalla("inicio")
    object Lista : Pantalla("lista")
    object Detalle : Pantalla("detalle/{itemId}") {
        fun crearRuta(id: Int) = "detalle/$id"
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    val listaTareas = remember {
        mutableStateListOf(
            Tarea(1, "Repasar Kotlin y Compose", completada = true),
            Tarea(2, "Completar la Práctica 12", completada = false),
            Tarea(3, "Subir cambios a GitHub", completada = false),
        )
    }

    NavHost(
        navController = navController,
        startDestination = Pantalla.Inicio.ruta
    ) {
        composable(Pantalla.Inicio.ruta) {
            InicioScreen(
                totalTareas = listaTareas.size
            ) { navController.navigate(Pantalla.Lista.ruta) }
        }

        composable(Pantalla.Lista.ruta) {
            ListaScreen(
                listaTareas = listaTareas,
                onNavegarADetalle = { id ->
                    navController.navigate(Pantalla.Detalle.crearRuta(id))
                }
            )
        }

        composable(
            route = Pantalla.Detalle.ruta,
            arguments = listOf(navArgument("itemId") { type = NavType.IntType })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getInt("itemId") ?: 0
            val tareaEncontrada = listaTareas.find { it.id == id }

            DetalleScreen(
                tarea = tareaEncontrada,
                onVolver = { navController.popBackStack() }
            )
        }
    }
}