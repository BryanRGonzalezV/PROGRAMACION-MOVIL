package com.ejemplo.practica03

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaPractica()
                }
            }
        }
    }
}

@Composable
fun PantallaPractica() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
    ) {
        Text(
            text = "Resultados Práctica 03",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // --- EJERCICIO 1: VALIDACIÓN NULL-SAFETY ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Ejercicio 1: Validación Null-Safety",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))

                val casos = listOf(
                    Pair(null, "test@mail.com"),
                    Pair("Ana", null),
                    Pair("Bo", "noesmail"),
                    Pair("Carlos Pérez", "carlos@ejemplo.com")
                )

                casos.forEach { (nombre, email) ->
                    val r = validarUsuario(nombre, email)
                    val estado = if (r.esValido) "OK" else "ERROR"
                    Text("[$estado] ${r.mensaje}")
                }
            }
        }

        // --- EJERCICIO 2: REGISTRO DE CALIFICACIONES ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Ejercicio 2: Registro de Calificaciones",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))

                val notas = mutableListOf(85, 92, 61, 78, 45, 90, 73, 55, 88, 67)
                Text(analizarNotas(notas))

                Text(
                    text = "--- Con nuevas notas ---",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
                notas.addAll(listOf(95, 40, 82))
                Text(analizarNotas(notas))
            }
        }

        // --- EJERCICIO 3: MAPA Y GROUPBY ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Ejercicio 3: Mapa de Estudiantes y groupBy",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(obtenerResumenEstudiantes())
            }
        }
    }
}

// ===================================================================
// LÓGICA DE LOS EJERCICIOS (Se declaran aquí para resolver el error)
// ===================================================================

data class ResultadoValidacion(val esValido: Boolean, val mensaje: String)

fun validarUsuario(nombre: String?, email: String?): ResultadoValidacion {
    val nombreLimpio = nombre?.trim()
    val longitudNombre = nombreLimpio?.length ?: 0

    if (longitudNombre < 3) {
        return ResultadoValidacion(false, "Nombre muy corto o vacío")
    }

    val emailValido = email?.contains('@') ?: false

    if (!emailValido) {
        return ResultadoValidacion(false, "Email inválido")
    }

    return ResultadoValidacion(true, "Usuario '$nombreLimpio' registrado correctamente")
}

fun analizarNotas(notas: List<Int>): String {
    if (notas.isEmpty()) return "Sin datos"

    val sb = StringBuilder()
    val promedio = notas.average()
    val aprobados = notas.filter { it >= 70 }
    val reprobados = notas.filter { it < 70 }
    val ordenadas = notas.sortedByDescending { it }
    val mayor = ordenadas.first()
    val menor = ordenadas.last()

    sb.appendLine("Total estudiantes : ${notas.size}")
    sb.appendLine("Promedio : $promedio")
    sb.appendLine("Aprobados : ${aprobados.size}")
    sb.appendLine("Reprobados : ${reprobados.size}")
    sb.appendLine("Nota más alta : $mayor")
    sb.appendLine("Nota más baja : $menor")

    val aprobadosOrdenados = aprobados.sortedByDescending { it }
    sb.appendLine("Notas aprobadas (mayor a menor) : $aprobadosOrdenados")

    val porcentajeAprobados = (aprobados.size.toDouble() / notas.size) * 100
    sb.appendLine("Porcentaje de aprobados : $porcentajeAprobados%")

    return sb.toString()
}

fun obtenerResumenEstudiantes(): String {
    val sb = StringBuilder()
    val estudiantes = mapOf(
        "Ana López" to 92,
        "Carlos Ruiz" to 65,
        "María Díaz" to 88,
        "Pedro Soto" to 55,
        "Laura Vega" to 75,
        "Juan Torres" to 48,
        "Sofía Reyes" to 91
    )

    val grupos = estudiantes.entries.groupBy { (_, nota) ->
        when {
            nota >= 90 -> "Sobresaliente"
            nota >= 70 -> "Aprobado"
            else -> "Reprobado"
        }
    }

    grupos.forEach { (categoria, lista) ->
        sb.appendLine("\n$categoria:")
        lista.forEach { (nombre, nota) ->
            sb.appendLine(" - $nombre: $nota")
        }
    }

    sb.appendLine("\n--- Resumen por categorías ---")
    grupos.forEach { (categoria, lista) ->
        sb.appendLine("$categoria: ${lista.size} estudiante(s)")
    }

    val estudianteNotaMasAlta = estudiantes.maxByOrNull { it.value }
    if (estudianteNotaMasAlta != null) {
        sb.appendLine("\nNota más alta: ${estudianteNotaMasAlta.key} (${estudianteNotaMasAlta.value})")
    }

    return sb.toString()
}