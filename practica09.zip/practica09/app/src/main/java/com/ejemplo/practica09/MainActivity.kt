package com.ejemplo.practica09

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ejemplo.practica09.ui.theme.Practica09Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Practica09Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PantallaDashboard()
                }
            }
        }
    }
}

// ── MODELO DE DATOS Y LISTA DE AFIRMACIONES ─────────────────────────

data class Afirmacion(val id: Int, val texto: String, val categoria: String)

// Afirmaciones originales + 4 propias (TODO resuelto)
val afirmaciones = listOf(
    Afirmacion(1, "El código limpio no se escribe, se refactoriza.", "Código"),
    Afirmacion(2, "Un bug encontrado es un bug que ya no puede fallar en producción.", "Debug"),
    Afirmacion(3, "Git commit temprano, git commit seguido.", "Versionamiento"),
    Afirmacion(4, "La documentación es una carta para tu yo futuro.", "Buenas prácticas"),
    Afirmacion(5, "Divide el problema y conquista.", "Algoritmos"),
    Afirmacion(6, "null es un valor, no un error: manéjalo.", "Kotlin"),
    Afirmacion(7, "El emulador es tu laboratorio: experimenta sin miedo.", "Android"),
    Afirmacion(8, "Cada práctica te acerca a tu primer app en producción.", "Motivación"),
    // 4 Afirmaciones Propias:
    Afirmacion(9, "Aprender el estado en Jetpack Compose es dominar la reactividad.", "Compose"),
    Afirmacion(10, "La consistencia diaria en la práctica supera al talento sin disciplina.", "Motivación"),
    Afirmacion(11, "Primero haz que funcione, luego haz que sea correcto, finalmente haz que sea rápido.", "Buenas prácticas"),
    Afirmacion(12, "Un layout eficiente es la clave de un rendimiento fluido a 60 fps.", "Android")
)

// ── PANTALLA PRINCIPAL DASHBOARD ──────────────────────────────────────

@Composable
fun PantallaDashboard() {
    var categoriaSeleccionada by remember { mutableStateOf("Todas") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Encabezado que ocupa el 15% de la altura
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.15f) // 15% de la Column
                .background(
                    MaterialTheme.colorScheme.primary,
                    RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "Mi Dashboard",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(16.dp))

        // Fila de estadísticas
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.20f),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TarjetaStat("Tareas", "12", Icons.Default.List, Modifier.weight(1f))
            TarjetaStat("Completadas", "8", Icons.Default.Check, Modifier.weight(1f))
            TarjetaStat("Pendientes", "4", Icons.Default.Pending, Modifier.weight(1f))
        }

        Spacer(Modifier.height(16.dp))

        // Sección inferior que ocupa el resto (weight 0.65f implícito al usar Column)
        Column(modifier = Modifier.weight(0.65f)) {
            Text(
                "Actividad reciente",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // TODO Resuelto: LazyRow arriba de la lista con chips de categorías
            val categorias = listOf("Todas") + afirmaciones.map { it.categoria }.distinct()

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                items(categorias) { cat ->
                    FilterChip(
                        selected = (cat == categoriaSeleccionada),
                        onClick = { categoriaSeleccionada = cat },
                        label = { Text(cat) }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // TODO Resuelto: LazyColumn filtrado por categoría
            val listaFiltrada = if (categoriaSeleccionada == "Todas") {
                afirmaciones
            } else {
                afirmaciones.filter { it.categoria == categoriaSeleccionada }
            }

            ListaAfirmaciones(
                afirmaciones = listaFiltrada,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

// ── COMPONENTES REUTILIZABLES ─────────────────────────────────────────

@Composable
fun TarjetaStat(titulo: String, valor: String, icono: ImageVector, modifier: Modifier) {
    Card(
        modifier = modifier,
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                icono,
                contentDescription = titulo,
                tint = MaterialTheme.colorScheme.primary
            )
            Text(valor, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                titulo,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ListaAfirmaciones(
    afirmaciones: List<Afirmacion>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 16.dp),
    ) {
        items(afirmaciones) { afirmacion ->
            ItemAfirmacion(afirmacion)
        }
    }
}

@Composable
fun ItemAfirmacion(afirmacion: Afirmacion) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Número de afirmación en círculo
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "${afirmacion.id}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    afirmacion.categoria,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Text(afirmacion.texto, fontSize = 14.sp)
            }
        }
    }
}

// ── PREVISUALIZACIÓN ──────────────────────────────────────────────────

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PrevisualizacionDashboard() {
    Practica09Theme {
        PantallaDashboard()
    }
}