package com.ejemplo.Practica02

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResultado = findViewById(R.id.tvResultado)
        val btnEjercicio1 = findViewById<Button>(R.id.btnEjercicio1)
        val btnEjercicio2 = findViewById<Button>(R.id.btnEjercicio2)
        val btnEjercicio3 = findViewById<Button>(R.id.btnEjercicio3)

        btnEjercicio1.setOnClickListener {
            mostrarEjercicio1()
        }

        btnEjercicio2.setOnClickListener {
            mostrarEjercicio2()
        }

        btnEjercicio3.setOnClickListener {
            mostrarEjercicio3()
        }
    }

    private fun mostrarEjercicio1() {
        val nombreCurso = "Programación Móvil I"
        val añoInicio = 2026
        var calificacion = 95.5
        calificacion = 88.0

        val nombreCompleto = "Tu Nombre Completo"
        val edadActual = 25

        tvResultado.text = """
            === EJERCICIO 1 ===
            Curso: $nombreCurso, Año: $añoInicio
            Calificación actual: ${calificacion * 0.3} (30%)
            Me llamo $nombreCompleto y tengo $edadActual años
        """.trimIndent()
    }

    private fun mostrarEjercicio2() {
        fun clasificarNota(nota: Int): String = when {
            nota < 0 || nota > 100 -> "Nota inválida"
            nota >= 90 -> "Sobresaliente (A)"
            nota >= 80 -> "Muy Bueno (B)"
            nota >= 70 -> "Bueno (C)"
            nota >= 60 -> "Aprobado (D)"
            else -> "Reprobado (F)"
        }

        val notas = listOf(100, 92, 85, 73, 61, 45, -5)
        var resultado = "=== EJERCICIO 2 ===\n"
        for (nota in notas) {
            resultado += "Nota $nota -> ${clasificarNota(nota)}\n"
        }

        // Reto adicional: versión con Double
        fun clasificarNotaDouble(nota: Double): String = when {
            nota < 0.0 || nota > 100.0 -> "Nota inválida"
            nota >= 90.0 -> "Sobresaliente (A)"
            nota >= 80.0 -> "Muy Bueno (B)"
            nota >= 70.0 -> "Bueno (C)"
            nota >= 60.0 -> "Aprobado (D)"
            else -> "Reprobado (F)"
        }

        val notasDouble = listOf(95.5, 87.3, 76.8, 62.5, 45.0)
        resultado += "\n--- Versión con Double ---\n"
        for (nota in notasDouble) {
            resultado += "Nota ${String.format("%.1f", nota)} -> ${clasificarNotaDouble(nota)}\n"
        }

        tvResultado.text = resultado
    }

    private fun mostrarEjercicio3() {
        // FizzBuzz
        var resultado = "=== EJERCICIO 3 - FizzBuzz ===\n"
        for (i in 1..30) {
            resultado += when {
                i % 15 == 0 -> "FizzBuzz "
                i % 3 == 0 -> "Fizz "
                i % 5 == 0 -> "Buzz "
                else -> "$i "
            }
            if (i % 10 == 0) resultado += "\n"
        }

        // Tabla de multiplicar
        resultado += "\n=== Tabla del 7 ===\n"
        for (i in 1..10) {
            resultado += "7 x $i = ${7 * i}\n"
        }

        tvResultado.text = resultado
    }
}