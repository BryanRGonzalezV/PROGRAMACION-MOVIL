package com.ejemplo.Practica02

data class Tarea(
    val id: Int,
    val texto: String,
    var completada: Boolean = false
)