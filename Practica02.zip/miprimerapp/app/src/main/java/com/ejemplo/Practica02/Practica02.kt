package com.ejemplo.Practica02



fun main() {

    // EJERCICIO 1: val, var e inferencia de tipos

    println("=== EJERCICIO 1 ===")

    // val: valor inmutable (no se puede reasignar)
    val nombreCurso = "Programación Móvil I"
    val añoInicio: Int = 2026

    // var: variable mutable (puede reasignarse)
    var calificacion: Double = 95.5
    calificacion = 88.0 // OK

    // String templates
    println("Curso: $nombreCurso, Año: $añoInicio")
    println("Calificación actual: ${calificacion * 0.3} (30%)")

    // TODO 1: Declara una val con tu nombre completo
    val nombreCompleto = "Tu Nombre Completo"  // ← CAMBIA ESTO

    // TODO 2: Declara una var con tu edad actual
    var edadActual = 25  // ← CAMBIA ESTO

    // TODO 3: Imprime: "Me llamo X y tengo Y años"
    println("Me llamo $nombreCompleto y tengo $edadActual años")


    // EJERCICIO 2: Clasificador de notas universitarias

    println("\n=== EJERCICIO 2 ===")

    fun clasificarNota(nota: Int): String = when {
        nota < 0 || nota > 100 -> "Nota inválida"
        nota >= 90 -> "Sobresaliente (A)"
        nota >= 80 -> "Muy Bueno (B)"
        nota >= 70 -> "Bueno (C)"
        nota >= 60 -> "Aprobado (D)"
        else -> "Reprobado (F)"
    }

    val notas = listOf(100, 92, 85, 73, 61, 45, -5)
    for (nota in notas) {
        println("Nota $nota -> ${clasificarNota(nota)}")
    }

    // 📌 RETO ADICIONAL: Versión con Double
    fun clasificarNotaDouble(nota: Double): String = when {
        nota < 0.0 || nota > 100.0 -> "Nota inválida"
        nota >= 90.0 -> "Sobresaliente (A)"
        nota >= 80.0 -> "Muy Bueno (B)"
        nota >= 70.0 -> "Bueno (C)"
        nota >= 60.0 -> "Aprobado (D)"
        else -> "Reprobado (F)"
    }

    println("\n--- Versión con Double (Reto adicional) ---")
    val notasDouble = listOf(95.5, 87.3, 76.8, 62.5, 45.0)
    for (nota in notasDouble) {
        println("Nota ${String.format("%.1f", nota)} -> ${clasificarNotaDouble(nota)}")
    }


    // EJERCICIO 3: FizzBuzz y tabla de multiplicar

    println("\n=== EJERCICIO 3 ===")

    // Parte A — FizzBuzz clásico (1 hasta 30)
    fun fizzBuzz() {
        println("\n--- FizzBuzz (1 al 30) ---")
        for (i in 1..30) {
            val resultado = when {
                i % 15 == 0 -> "FizzBuzz"
                i % 3 == 0 -> "Fizz"
                i % 5 == 0 -> "Buzz"
                else -> "$i"
            }
            print("$resultado ")
            if (i % 10 == 0) println()
        }
    }

    // Parte B — Tabla de multiplicar de un número
    fun tablaMultiplicar(n: Int) {
        println("\n=== Tabla del $n ===")
        for (i in 1..10) {
            println("$n x $i = ${n * i}")
        }
    }

    fizzBuzz()

    // TODO: Pedir al usuario un número con readLine() y mostrar su tabla
    println("\n--- Tabla de multiplicar ---")
    println("Ingresa un número (presiona Enter para usar 7):")
    val num = readLine()?.toIntOrNull() ?: 7
    tablaMultiplicar(num)

    println("\n✅ PRÁCTICA 02 COMPLETADA CON ÉXITO")
}